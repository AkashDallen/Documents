import React, { Component } from 'react'

export class Description extends Component {
    render() {
        return (
            <div>
                <h1>decsc</h1>
            </div>
        )
    }
}

export default Description
