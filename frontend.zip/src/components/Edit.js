import React, { Component } from 'react'
import axios from 'axios';
import { Link } from 'react-router-dom';
export class Edit extends Component {
    constructor(props){
        super(props);
        this.state={
            name:"",
            
        }
    }
    componentDidMount=()=>{
        const id=this.props.match.params.id;
        if(!id){
            return
        }
        axios.get(`http://localhost:4000/book/${id}`).then((res)=>{
            const book = res.data.book[0];
            console.log(book)
            this.setState(()=>({name:book.name}))
        }).catch((err)=>{
            console.log(err);
        })
    }
    handleclick=(e,id)=>{
        const value=e.target.value;
        this.setState(()=>({
           [`${id}`]:value
        }))
    }
    saveChanges=()=>{
        const id = this.props.match.params.id;
        const book={
            isbn:id,
            name:this.state.name,
        }
        axios.put(`http://localhost:4000/book/${id}`,book).then((res)=>{
            this.props.history.push('/');

        }).catch((er)=>{
            console.log(er);
        })
    }
    render() {
        return (
            <div>
                <form>
                    <input type="text" onChange={(e)=>{this.handleclick(e,'name')}}></input>
                    <button onClick={this.saveChanges}>save changes</button>
                </form>
                <Link to='/'>back</Link>
            </div>
        )
    }
}

export default Edit
